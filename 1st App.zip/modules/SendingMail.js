var nodemailer = require('nodemailer');
module.exports={

    SendMail : function(mailTo,htmlContent){

       let transport= nodemailer.createTransport({
            service:'gmail',
            auth:{
                user:"mmukulssingh@gmail.com",
                pass:'donnoone1@'
            }
            })

        mailTo.split(',').forEach(mail => {
            
            let mailerOptions = {
                forceEmbeddedImages: true,
                   from:'mmukulssingh@gmail.com',
                   to:mail,
                   subject:'CodeGyaan',
                   html:htmlContent
        
               }     
        
               transport.sendMail(mailerOptions,(e,info)=>{
                   if(e.message) return console.log(e.message);
        
                   console.log(info)
               })
        });    
      

    }
}

